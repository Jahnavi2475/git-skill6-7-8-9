package com.example.librarydemo.controller;

import com.example.librarydemo.model.Book;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class LibraryController {

    List<Book> bookList = new ArrayList<>();

    // 1 Welcome message
    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome to Online Library System";
    }

    // 2 Count books
    @GetMapping("/count")
    public int countBooks() {
        return 100;
    }

    // 3 Book price
    @GetMapping("/price")
    public double bookPrice() {
        return 499.99;
    }

    // 4 List of book titles
    @GetMapping("/books")
    public List<String> getBooks() {

        List<String> titles = new ArrayList<>();
        titles.add("Java Programming");
        titles.add("Spring Boot Guide");
        titles.add("Data Structures");

        return titles;
    }

    // 5 Book details using path variable
    @GetMapping("/books/{id}")
    public String getBookById(@PathVariable int id) {
        return "Details of Book ID: " + id;
    }

    // 6 Search book
    @GetMapping("/search")
    public String searchBook(@RequestParam String title) {
        return "Searching for book: " + title;
    }

    // 7 Author books
    @GetMapping("/author/{name}")
    public String getAuthor(@PathVariable String name) {
        return "Books written by Author: " + name;
    }

    // 8 Add book
    @PostMapping("/addbook")
    public String addBook(@RequestBody Book book) {

        bookList.add(book);

        return "Book added successfully";
    }

    // 9 View books
    @GetMapping("/viewbooks")
    public List<Book> viewBooks() {
        return bookList;
    }

}